# docs
* [spring](spring.md)
* [spring bean](spring-bean.md)
* [ioc](ioc.md)
* [BeanFactory vs ApplicationContext](beanfactory-vs-applicationcontext.md)
* [bean-wiring](bean-wiring.md)
* [autowiring](autowiring.md)

<br/>

* [aop](aop.md)
* [mvc](mvc.md)
* [rest](rest.md)
* [orm](orm.md)

<br/>

* [data](../examples/spring-data)
* [boot](../examples/spring-boot-web)
