var app = angular.module('SpringSample', []);
var domain = 'http://localhost:8085/';
//Application just started.
var applicationStarted = true;