var app = angular.module('SpringSample', []);
var domain = 'http://localhost:8080/SpringSampleMVC/';
//Application just started.
var applicationStarted = true;