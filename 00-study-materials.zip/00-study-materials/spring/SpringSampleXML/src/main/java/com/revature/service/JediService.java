package com.revature.service;

import java.util.List;

import com.revature.model.Jedi;

public interface JediService {
	public List<Jedi> getAllJedis();
}
