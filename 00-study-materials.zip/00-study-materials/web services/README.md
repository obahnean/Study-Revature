# soap

This directory includes
* examples
* docs in the `docs/` directory

### links
* [soap](docs/soap.md)
* [wsdl](docs/wsdl.md)
* [soap message](docs/soap-message.md)
