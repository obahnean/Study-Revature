package com.revature.day3.oop;

public interface Airlines {

	public void bookAFlight();
	public void onlineCheckIn();
	public void baggageAllowane();
	public void fareRules();
	public void numberOfStops();
}
