package com.revature.day3.oop;

public abstract class Airways {
	
	
	
	public abstract void one();
	
	public void two(){
		System.out.println("two");
	}
}
