package com.revature.day3.oop;

public class AmericanAirlines extends Airways{

	@Override
	public void one() {
		System.out.println("two - AA");
	}


	
}
