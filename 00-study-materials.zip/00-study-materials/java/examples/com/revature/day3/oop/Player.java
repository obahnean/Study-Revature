package com.revature.day3.oop;

public class Player {

	void name(){
		System.out.println("Bob");
	}
	
	void age(){
		System.out.println("57");
	}
	
	void nationality(){
		System.out.println("Checz Republic");
	}
	
	protected void medals(){
		System.out.println("Player owns their individuals medals");
	}
}
