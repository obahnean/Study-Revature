package com.revature.day3.oop;

public class CapitalOne {

	public static void main(String[] args) {
		Bank b1 = new Bank();
		b1.setAccountBalance(100.00);
		b1.setAccountNumber(1234567890);
		b1.getAccountNumber();
	}

}
