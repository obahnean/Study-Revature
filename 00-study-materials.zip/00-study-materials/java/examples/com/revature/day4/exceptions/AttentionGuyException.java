package com.revature.day4.exceptions;

public class AttentionGuyException extends Exception {
	private static final long serialVersionUID = -6164349961501290215L;
	
	public AttentionGuyException() {
		super("I seek attention.");
	}
}
