package com.revature;
public class HelloWorld {
	//sysout
	//line comments
	/*
	 * Ctrl+D to delete a line
	 * This is multi line comments
	 */
	public static void main(String[] args) {
		
		System.out.println("Hello world");		//this is simple print statement on the console
		//declare and initialize the variable of data type int
		int i = 10;
		System.out.printf("Value of %d \n", i);
		//print empty next line
		//System.out.println();
		String s1 = "This is an example of string";
		System.out.printf("Value of %s \n", s1);
	}
}
