package com.revature.day5.designpatterns;

public class Main {

	public static void main(String[] args) {
		//CreationPattern c1 = new CreationPattern();
		System.out.println(CreationPattern.getInstance().getClass());
	}

}
