# Debug
* Java Debugger allows you to step through your program line by line

### Terms
* **Breakpoint**: where to stop
* **Step over**
* **Step into**
* **Step out**

[example](../examples/debug/)
