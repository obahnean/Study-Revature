# final
* `final` is a keyword

# final classes
* cannot be extended

# final methods
* cannot be overridden

# final variable
* cannot be reassigned
* IQ: difference between final variables and immutable objects
