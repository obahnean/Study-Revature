# reflection
* inspect classes at runtime
* do not need to know the class name at compile time
* `Class`, `Field`, `Method`, `Constructor`

let's see an example
