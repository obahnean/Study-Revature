# Java build artifacts
* zip files
* it is easier to pass around a single, compressed file

# Java Archive (JAR)
* collection of `.class` files

# Web Archive (WAR)
* JARs, HTML, CSS, JavaScript

# Enterprise Archive (EAR)
* WARs, EJBs
