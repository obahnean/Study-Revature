# Why Java
* Portable
* C Syntax
* Verbose libraries
* Free *(not open source)*
* Easy to learn
  * Memory management
  * No pointers
* Popular
* Object-oriented
  * Polymorphism
  * Inheritance
  * Abstraction
  * Encapsulation
