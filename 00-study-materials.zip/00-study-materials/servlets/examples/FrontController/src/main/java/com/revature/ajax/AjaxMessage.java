package com.revature.ajax;

public class AjaxMessage {
	private String message;
	
	public AjaxMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
