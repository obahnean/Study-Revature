package com.revature.util;

import org.apache.log4j.Logger;

/* Final utility class containing root logger declaration used across the project */
public final class LogUtil {

	public final static Logger logger = Logger.getRootLogger();
}
