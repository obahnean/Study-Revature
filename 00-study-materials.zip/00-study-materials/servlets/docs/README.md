# Servlets

* [servlets](servlets/docs/servlets.md)
* [redirect vs forward](servlets/docs/redirect-vs-forward.md)
* [printwriter](servlets/docs/printwriter.md)
* [http session](servlets/docs/http-session.md)
* [ServletContext and ServletConfig](servlets/docs/servletcontext-and-servletconfig.md)

<br/>

* [http status codes](servlets/docs/http-status-codes.md)
* [http methods](servlets/docs/http-methods.md)
