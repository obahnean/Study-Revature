# HTTP Methods
* GET
* PUT
* POST
* DELETE
* PATCH
* OPTIONS
* TRACE
* HEAD
* CONNECT

# GET vs POST
* GET can only send data in url
  * limited
  * can bookmark or copy url and email to a friend
* POST can send data in request body
  * unlimited
  * more secure
