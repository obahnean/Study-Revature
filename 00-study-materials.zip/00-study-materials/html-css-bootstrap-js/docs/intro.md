# intro
* JavaScript is widely used in browsers
* while running in the browser, the global object is called `window`
* the Document Object Model (DOM) is a tree of JavaScript objects that is used to render a view
* we can use JavaScript to manipulate the DOM and create dynamic applications
