### Background
* Almost completely unrelated to Java
* Loosely typed
* A lot of bad and good parts
* No classes
* Object oriented

### Key Ideas
* Load and go delivery
* Loose typing
* Object as general containers
* Prototypal inheritance
* Lambda
* Linkage through global variables 

### C
* JavaScript is syntactically a C family language
* It differs from C mainly in its type system, which allows functions to be  values


