# bootstrap
* Created by Twitter
* CSS library (a giant CSS file)
  * also includes JavaScript and fonts
* mobile first
* responsive


### Using Bootstrap's JavaScript
* Bootstrap's JavaScript file depends on jQuery

### How to use Bootstrap
* can download css, js, font files
* can use CDN
