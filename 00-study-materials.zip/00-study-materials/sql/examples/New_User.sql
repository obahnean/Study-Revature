create user username IDENTIFIED by p4ssw0rd;

grant connect, resource to username;

grant connect, resource to yuvirds;
GRANT DBA TO yuvirds WITH ADMIN OPTION;
