# Database
* A way to persist data
* Well defined rules

problem
* no name
* balance is not a number

```
<account>
  <balance>hello world</balance>
</account>
```

# RDBMS
* Relational Database Management System
* One category of databases
* a relational database is a collection of tables
  * relation == table
* Common relational databases
  * OracleDB
  * MySQL
  * PostgreSQL
  * MariaDB
  * SQL Server
* Another category is **NoSQL** (graph, document, key/value)
