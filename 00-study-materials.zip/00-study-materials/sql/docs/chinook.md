# chinook database
* example database

# setting it up
* [link](https://chinookdatabase.codeplex.com/)
  * select **download**
* unzip
* open file `Chinook_Oracle.sql`
* copy/paste contents into SQL Developer worksheet
  * ensure you are using **firstname-rds** connection
* highlight everything and click green arrow to run
  * this will take 20-30 minutes
* create connection using same Endpoint with username: **chinook** and password: **p4ssw0rd**


# data model
* the [data model](https://chinookdatabase.codeplex.com/wikipage?title=Chinook_Schema&referringTitle=Documentation) shows the structure of the chinook database
