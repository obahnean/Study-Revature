# Oracle SQL Developer
* GUI for manipulating a database
* made by Oracle
* [download link](http://www.oracle.com/technetwork/developer-tools/sql-developer/downloads/index.html)
